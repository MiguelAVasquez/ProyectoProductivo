/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemplo1;

/**
 *
 * @author SenaNoche
 */
public class Ejemplo1 {
    public String Nombre;
    public int Edad;

    public Ejemplo1(String Nombre, int Edad) {
        this.Nombre = Nombre;
        this.Edad = Edad;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }
    
    
    public static void main(String[] args) {
        Ejemplo1 persona= new Ejemplo1("manuel",23);
        System.out.println();
       // print(hola.getColor());
        System.out.println(persona.Nombre+" y su edad es: "+(persona.Edad));
       // System.out.println(hola.color);
       imprimir("manuel", 13);

    }
    public static void imprimir(String lol,int loo){
        System.out.print(lol+loo);
    }
}
