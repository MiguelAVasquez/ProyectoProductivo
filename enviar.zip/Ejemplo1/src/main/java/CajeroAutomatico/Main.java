package CajeroAutomatico;

import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
    
        //Scanner scanner = new Scanner(System.in);
        //String nombreCliente = scanner.next();
        
        Cliente cliente1 = new Cliente(Cliente.intp(),Cliente.intp2(),Cliente.intp2(),Cliente.intp(),Cliente.intp2());
        
        cliente1.retirarDinero(Cliente.intp2());
        cliente1.imprimir();

    }
}
