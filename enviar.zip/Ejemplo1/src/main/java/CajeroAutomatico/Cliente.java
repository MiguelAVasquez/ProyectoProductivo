package CajeroAutomatico;

import java.util.Scanner;
//import java.util.List;


public class Cliente extends CajeroAutomatico{
    
    private String nombreCliente;
    private int idCliente;

    public Cliente(String nombreCliente, int idCliente, int tipoBilletes, String tipoTransaccion, int numCuenta, int numPass, String tipoCuenta, int saldoCuenta) {
        super(tipoBilletes, tipoTransaccion, numCuenta, numPass, tipoCuenta, saldoCuenta);
        this.nombreCliente = nombreCliente;
        this.idCliente = idCliente;
    }

    public Cliente(String nombreCliente, int idCliente, int tipoBilletes, String tipoTransaccion, int saldoCuenta) {
        super(tipoBilletes, tipoTransaccion,saldoCuenta);
        this.nombreCliente = nombreCliente;
        this.idCliente = idCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    
    public void imprimir() {
        System.out.println(nombreCliente);
        System.out.println(idCliente);
        System.out.println(getTipoBilletes());
        System.out.println(getTipoTransaccion());
        System.out.println(getSaldoCuenta());
        
    }
    public static String intp(){
        System.out.println("ingrese un dato texto");
        Scanner scanner = new Scanner(System.in);
         String intp=scanner.next();
         return intp;
    }
    public static int intp2(){
        System.out.println("ingrese un dato ${alas}");
        Scanner scanner = new Scanner(System.in);
        int intp=scanner.nextInt();
         return intp;
    }
    
     public int retirarDinero(int retiro){
        int i = getSaldoCuenta() - retiro;
        setSaldoCuenta(i);
        return i;
    }
}
