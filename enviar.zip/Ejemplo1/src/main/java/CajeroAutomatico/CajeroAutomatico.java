package CajeroAutomatico;

public class CajeroAutomatico {
    
    private int TipoBilletes;
    private String tipoTransaccion;
    private int numCuenta;
    private int numPass;
    private String tipoCuenta;
    private int saldoCuenta;

    public CajeroAutomatico(int TipoBilletes, String tipoTransaccion, int numCuenta, int numPass, String tipoCuenta, int saldoCuenta) {
        this.TipoBilletes = TipoBilletes;
        this.tipoTransaccion = tipoTransaccion;
        this.numCuenta = numCuenta;
        this.numPass = numPass;
        this.tipoCuenta = tipoCuenta;
        this.saldoCuenta = saldoCuenta;
    }
    public CajeroAutomatico(int tipoBilletes, String tipoTransaccion, int saldoCuenta){
        this.TipoBilletes = tipoBilletes;
        this.tipoTransaccion = tipoTransaccion;
        this.saldoCuenta=saldoCuenta;
    }
    

    public int getTipoBilletes() {
        return TipoBilletes;
    }

    public void setTipoBilletes(int TipoBilletes) {
        this.TipoBilletes = TipoBilletes;
    }

    public String getTipoTransaccion() {
        return tipoTransaccion;
    }

    public void setTipoTransaccion(String tipoTransaccion) {
        this.tipoTransaccion = tipoTransaccion;
    }

    public int getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    public int getNumPass() {
        return numPass;
    }

    public void setNumPass(int numPass) {
        this.numPass = numPass;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public int getSaldoCuenta() {
        return saldoCuenta;
    }

    public void setSaldoCuenta(int saldoCuenta) {
        this.saldoCuenta = saldoCuenta;
    }
    
   
}
